/*******************************************************************************
 * Copyright (c) 2014 OSSMETER Partners.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    James Williams - Implementation.
 *******************************************************************************/
package org.eclipse.scava.platform.app.example;

import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.scava.platform.ExtensionPointMetricProviderManager;
import org.eclipse.scava.platform.IMetricProviderManager;
import org.eclipse.scava.platform.Platform;
import org.eclipse.scava.platform.admin.AdminApplication;
import org.eclipse.scava.platform.delta.bugtrackingsystem.ExtensionPointBugTrackingSystemManager;
import org.eclipse.scava.platform.delta.bugtrackingsystem.PlatformBugTrackingSystemManager;
import org.eclipse.scava.platform.delta.communicationchannel.ExtensionPointCommunicationChannelManager;
import org.eclipse.scava.platform.delta.communicationchannel.PlatformCommunicationChannelManager;
import org.eclipse.scava.platform.delta.vcs.ExtensionPointVcsManager;
import org.eclipse.scava.platform.delta.vcs.PlatformVcsManager;

import com.googlecode.pongo.runtime.PongoFactory;
import com.googlecode.pongo.runtime.osgi.OsgiPongoFactoryContributor;
import com.mongodb.Mongo;

public class DemoApp implements IApplication {
	
	Mongo mongo;
	
	public void run(IMetricProviderManager metricProviderManager, PlatformVcsManager platformVcsManager,
						PlatformCommunicationChannelManager communicationChannelManager, PlatformBugTrackingSystemManager bugTrackingSystemManager) throws Exception {

		// TODO: The platform needs to have been started for the API to work.
		mongo = new Mongo();
		PongoFactory.getInstance().getContributors().add(new OsgiPongoFactoryContributor());
		Platform platform = new Platform(mongo); 
//		platform.setMetricProviderManager(metricProviderManager);
//		platform.setPlatformVcsManager(platformVcsManager);
//		platform.setPlatformCommunicationChannelManager(communicationChannelManager);
//		platform.setPlatformBugTrackingSystemManager(bugTrackingSystemManager);

		AdminApplication app = new AdminApplication();
		
		while (true) {
			try{
				Thread.sleep(50000000);
			} catch (Exception e) {
				throw e;
			}
		}
	}
	
	@Override
	public Object start(IApplicationContext context) throws Exception {
		run(new ExtensionPointMetricProviderManager(), null, null, null);
		return IApplication.EXIT_OK;
	}

	@Override
	public void stop() {
		//nothing to do	
		if (mongo != null) {
			mongo.close();
		}
	}
}
